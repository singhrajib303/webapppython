# Deploy a basic Django app to Azure

Follow the tutorial [here](https://stories.mlh.io/deploying-a-basic-django-app-using-azure-app-services-71ec3b21db08)!
